import 'package:bt_form_xlsk/bai_tap/bai07/DefaultTabController.dart';
import 'package:flutter/material.dart';

class Bai07 extends StatelessWidget {
  const Bai07({super.key});

  @override
  Widget build(BuildContext context) {
    return const defaultTabController();
  }
}